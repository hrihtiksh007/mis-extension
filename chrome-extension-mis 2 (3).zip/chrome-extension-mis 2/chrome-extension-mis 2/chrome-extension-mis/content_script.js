(function() {
  'use strict';

  // --- CONFIGURATION ---
  const REQUIRED_ATTENDANCE_RATIO = 0.75;
  // --- END OF CONFIGURATION ---

  /**
   * Injects the core UI for the calculator and its functional styles. This runs on all pages.
   */
  function injectCoreStylesAndUI() {
    if (document.getElementById('calc-mode-panel')) return;

    const controlPanel = document.createElement('div');
    controlPanel.id = 'calc-mode-panel';
    controlPanel.innerHTML = `
      <span class="calc-mode-label">Calc Mode</span>
      <label class="calc-mode-switch">
        <input type="checkbox" id="calc-mode-toggle">
        <span class="calc-mode-slider"></span>
      </label>
    `;
    document.body.appendChild(controlPanel);

    const styles = `
      /* --- Extension UI and Functional Styles --- */
      #calc-mode-panel { position: fixed; top: 20px; right: 20px; z-index: 9999; background: rgba(44, 62, 80, 0.9) !important; color: white !important; padding: 8px 15px; border-radius: 50px; display: flex; align-items: center; box-shadow: 0 4px 10px rgba(0,0,0,0.3) !important; backdrop-filter: blur(5px); font-family: sans-serif; }
      .calc-mode-label { margin-right: 10px; font-weight: bold; font-size: 14px; }
      .calc-mode-switch { position: relative; display: inline-block; width: 50px; height: 28px; }
      .calc-mode-switch input { opacity: 0; width: 0; height: 0; }
      .calc-mode-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #7f8c8d; transition: .4s; border-radius: 28px; }
      .calc-mode-slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
      input:checked + .calc-mode-slider { background-color: #2ecc71; }
      input:checked + .calc-mode-slider:before { transform: translateX(22px); }
      .calc-mode-header, .calc-mode-cell { display: none !important; text-align: center; vertical-align: middle; }
      .calc-mode-controls { display: none !important; text-align: center; vertical-align: middle; }
      body.calc-mode-active .calc-mode-header, body.calc-mode-active .calc-mode-controls { display: table-cell !important; }
      body.calc-mode-active .calc-mode-cell { display: table-cell !important; }
      #generated-summary-table .calc-mode-cell { display: table-cell !important; }
      .percentage-cell { text-align: right; padding-right: 15px !important; }
      .percentage-cell.low-attendance { color: #e74c3c; font-weight: bold; }
      .percentage-cell.high-attendance { color: #27ae60; font-weight: bold; }
      .bunk-button { cursor: pointer; background: #e74c3c; color: white; border: none; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 12px; transition: background-color 0.2s; }
      .bunk-button:hover { background: #c0392b; }
      .bunk-counter { font-size: 1em; font-weight: bold; color: #c0392b; margin-left: 8px; vertical-align: middle; }
      #generated-summary-table { margin: 25px auto !important; width: 80% !important; max-width: 900px; border-collapse: collapse; }
      #generated-summary-table th, #generated-summary-table td { border: 1px solid #ccc; padding: 8px; }
      #generated-summary-table th { background-color: #f2f2f2; }
    `;

    const styleSheet = document.createElement("style");
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);

    document.getElementById('calc-mode-toggle').addEventListener('change', (event) => {
      document.body.classList.toggle('calc-mode-active', event.target.checked);
      if (!event.target.checked) {
        document.querySelectorAll('tr[data-original-total]').forEach(resetRow);
      }
    });
  }
  
  function injectVisualTheme() {
    const styles = `
      body { background-image: url('https://storage.googleapis.com/gweb-uniblog-publish-prod/original_images/tenor_1.gif') !important; background-size: cover !important; background-position: center !important; background-attachment: fixed !important; }
      div:not(.container) { background: none !important; background-color: transparent !important; border: none !important; box-shadow: none !important; }
      table { background-color: rgba(255, 255, 255, 0.1) !important; border-radius: 12px !important; box-shadow: 0 8px 32px 0 rgba(38, 18, 18, 0.3) !important; backdrop-filter: blur(8px) !important; border: 1px solid rgba(255, 255, 255, 0.18) !important; }
      th { background-color: rgba(255, 255, 255, 0.2) !important; color: #333 !important; }
      #generated-summary-table { border: 1px solid rgba(255, 255, 255, 0.18) !important; }
      #generated-summary-table th, #generated-summary-table td { border: none !important; border-bottom: 1px solid rgba(18, 34, 209, 0.05) !important;}
    `;
    const styleSheet = document.createElement("style");
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);
  }

  function recalculateRow(row) {
    const originalTotal = parseInt(row.dataset.originalTotal, 10) || 0;
    const originalAttended = parseInt(row.dataset.originalAttended, 10) || 0;
    const bunkedCount = parseInt(row.dataset.bunkedCount, 10) || 0;
    const currentTotal = originalTotal + bunkedCount;
    const currentAttended = originalAttended;

    const headerRow = row.closest('table')?.querySelector('tr:has(th)');
    if (!headerRow) return;

    const totalCellIndex = Array.from(headerRow.cells).findIndex(th => {
        const text = th.textContent.toLowerCase();
        return text.includes('conducted') || text.includes('total lectures');
    });

    if (totalCellIndex !== -1 && row.cells[totalCellIndex]) {
        row.cells[totalCellIndex].textContent = currentTotal;
    }

    const percentageCell = row.querySelector('.percentage-cell');
    const percentage = currentTotal > 0 ? (currentAttended / currentTotal) * 100 : 0;
    
    if(percentageCell) {
        percentageCell.textContent = percentage.toFixed(2);
        percentageCell.classList.toggle('low-attendance', percentage < REQUIRED_ATTENDANCE_RATIO * 100);
        percentageCell.classList.toggle('high-attendance', percentage >= REQUIRED_ATTENDANCE_RATIO * 100);
    }
    
    const moreToGoCell = row.querySelector('.more-to-go-cell');
    const canSkipCell = row.querySelector('.can-skip-cell');
    
    if (percentage < REQUIRED_ATTENDANCE_RATIO * 100) {
      const needed = Math.ceil((REQUIRED_ATTENDANCE_RATIO * currentTotal - currentAttended) / (1 - REQUIRED_ATTENDANCE_RATIO));
      if (moreToGoCell) moreToGoCell.textContent = needed > 0 ? needed : 0;
      if (canSkipCell) canSkipCell.textContent = "0";
    } else {
      const skippable = Math.floor((currentAttended / REQUIRED_ATTENDANCE_RATIO) - currentTotal);
      if (moreToGoCell) moreToGoCell.textContent = "0";
      if (canSkipCell) canSkipCell.textContent = skippable;
    }
    
    const bunkCounter = row.querySelector('.bunk-counter');
    if (bunkCounter) bunkCounter.textContent = `(+${bunkedCount})`;
  }

  function resetRow(row) {
    row.dataset.bunkedCount = 0;
    recalculateRow(row);
  }
  
  function addBunkingLogicToRow(row) {
      const bunkButton = row.querySelector('.bunk-button');
      if (bunkButton) {
          bunkButton.addEventListener('click', () => {
              row.dataset.bunkedCount = (parseInt(row.dataset.bunkedCount, 10) || 0) + 1;
              recalculateRow(row);
          });
      }
  }

  function parseDateFromCell(dateString, year) {
    const monthMap = { 'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04', 'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08', 'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12' };
    const parts = dateString.split('-');
    if (parts.length < 2) return null;
    const day = parts[0].padStart(2, '0');
    const month = monthMap[parts[1]];
    if (!month || !day || !year) return null;
    return new Date(`${year}-${month}-${day}T00:00:00Z`);
  }

  function processItineraryPage() {
    const CALCULATION_START_DATE_STRING = '2025-08-04';
    const CALCULATION_START_DATE = new Date(CALCULATION_START_DATE_STRING + 'T00:00:00Z');
    const subjects = {};
    
    const itineraryTable = Array.from(document.querySelectorAll('table')).find(
        table => table.textContent.toUpperCase().includes('DATE') && table.textContent.toUpperCase().includes('SLOT 1')
    );
    if (!itineraryTable) return;

    let reportYear = new Date().getFullYear();
    const headerCell = Array.from(document.querySelectorAll('th, td')).find(th => /report from/i.test(th.textContent));
    if (headerCell) {
      const matches = headerCell.textContent.match(/\b\d{4}\b/g);
      if (matches) reportYear = parseInt(matches[matches.length - 1], 10);
    }
    
    itineraryTable.querySelectorAll('tr').forEach(row => {
      if (row.querySelector('th') || row.cells.length < 2 || !row.cells[0]?.textContent?.trim()) {
        return;
      }
      const dateCell = row.cells[0];
      const dateText = dateCell.textContent.trim().split(' ')[0];
      const currentDate = parseDateFromCell(dateText, reportYear);
      if (!currentDate || currentDate < CALCULATION_START_DATE) return;

      for (let i = 1; i < row.cells.length; i++) {
        const cell = row.cells[i];
        if (!cell) continue;
        const text = cell.textContent.trim();
        if (text === '' || text === '::') continue;
        const parts = text.split(':').map(p => p.trim());
        if (parts.length !== 3) continue;
        const subjectCode = parts[1];
        const lectureType = parts[2];
        if (lectureType.toUpperCase() !== 'T') continue;
        if (!subjects[subjectCode]) subjects[subjectCode] = { total: 0, attended: 0, name: subjectCode };
        subjects[subjectCode].total++;
        const style = window.getComputedStyle(cell);
        const [r,g,b] = style.backgroundColor.match(/\d+/g) || [0,0,0];
        if (!(parseInt(r) > 240 && parseInt(g) < 200 && parseInt(b) < 200)) {
           subjects[subjectCode].attended++;
        }
      }
    });

    if (Object.keys(subjects).length === 0) return;

    const summaryTable = document.createElement('table');
    summaryTable.id = 'generated-summary-table';
    summaryTable.innerHTML = `
      <thead>
        <tr><th colspan="7" style="text-align: center;">Theory Attendance From ${CALCULATION_START_DATE_STRING} Onwards</th></tr>
        <tr><th>Subject</th><th>Total</th><th>Attended</th><th>(%)</th><th class="calc-mode-cell">More to Go</th><th class="calc-mode-cell">Can Skip</th><th class="calc-mode-controls">Bunk +1</th></tr>
      </thead>
      <tbody>
        ${Object.values(subjects).sort((a,b) => a.name.localeCompare(b.name)).map(data => {
            const { name, total, attended } = data;
            const percentage = total > 0 ? (attended / total) * 100 : 0;
            let needed = 0, skippable = 0;
            if (percentage < REQUIRED_ATTENDANCE_RATIO * 100) {
                needed = Math.ceil((REQUIRED_ATTENDANCE_RATIO * total - attended) / (1 - REQUIRED_ATTENDANCE_RATIO));
            } else {
                skippable = Math.floor((attended / REQUIRED_ATTENDANCE_RATIO) - total);
            }
            return `
              <tr data-original-total="${total}" data-original-attended="${attended}" data-bunked-count="0">
                <td>${name}</td>
                <td>${total}</td>
                <td>${attended}</td>
                <td class="percentage-cell ${percentage < REQUIRED_ATTENDANCE_RATIO * 100 ? 'low-attendance' : 'high-attendance'}">${percentage.toFixed(2)}</td>
                <td class="calc-mode-cell more-to-go-cell">${needed > 0 ? needed : 0}</td>
                <td class="calc-mode-cell can-skip-cell">${skippable}</td>
                <td class="calc-mode-controls"><button class="bunk-button">[+]</button><span class="bunk-counter">(+0)</span></td>
              </tr>`;
          }).join('')}
      </tbody>
    `;
    itineraryTable.parentNode.insertBefore(summaryTable, itineraryTable);
    summaryTable.querySelectorAll('tbody tr').forEach(addBunkingLogicToRow);
  }

  function processSummaryPage(table) {
      if (table.querySelector('.calc-mode-header')) return;
      const headerRow = table.querySelector('tr:has(th)');
      if (!headerRow) return;

      const lectureHeaderIndex = Array.from(headerRow.cells).findIndex(th => {
        const text = th.textContent.toLowerCase();
        return text.includes('conducted') || text.includes('total lectures');
      });
      
      const attendedHeaderIndex = lectureHeaderIndex + 1;
      const percentageHeaderIndex = attendedHeaderIndex + 1;
      
      if (lectureHeaderIndex === -1 || !headerRow.cells[attendedHeaderIndex] || !headerRow.cells[percentageHeaderIndex]) return;
      
      headerRow.insertAdjacentHTML('beforeend', `<th class="calc-mode-header">More to Go</th><th class="calc-mode-header">Can Skip</th><th class="calc-mode-controls">Bunk +1</th>`);
      
      table.querySelectorAll('tbody > tr, tr:has(td)').forEach((row) => {
        if (!row.cells[percentageHeaderIndex] || row.textContent.toLowerCase().includes('total')) return;
        row.dataset.originalTotal = row.cells[lectureHeaderIndex].textContent.trim();
        row.dataset.originalAttended = row.cells[attendedHeaderIndex].textContent.trim();
        row.dataset.bunkedCount = 0;
        row.cells[percentageHeaderIndex].classList.add('percentage-cell');
        row.insertCell().classList.add('calc-mode-cell', 'more-to-go-cell');
        row.insertCell().classList.add('calc-mode-cell', 'can-skip-cell');
        const controlsCell = row.insertCell();
        controlsCell.classList.add('calc-mode-controls');
        controlsCell.innerHTML = `<button class="bunk-button">[+]</button><span class="bunk-counter">(+0)</span>`;
        addBunkingLogicToRow(row);
        recalculateRow(row);
      });
  }

  function run() {
    injectCoreStylesAndUI();
    const hostname = window.location.hostname;
    const url = window.location.href.toLowerCase();

    // --- UPDATED LOGIC ---
    // This now applies the theme to any site with 'aldel' in the name
    if (hostname.includes('aldel')) {
      injectVisualTheme();
    }
    // --- END OF UPDATE ---
    
    if (url.includes('itinerary_attendance_report.php') || url.includes('itinenary_attendance_report.php')) {
      processItineraryPage();
    } else {
      const processedTables = new Set();
      document.querySelectorAll('th').forEach(headerCell => {
        if (headerCell.textContent.toLowerCase().includes('subject')) {
          const table = headerCell.closest('table');
          if (table && !processedTables.has(table)) {
              processSummaryPage(table);
              processedTables.add(table);
          }
        }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();